package telran.ashkelon2020;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
